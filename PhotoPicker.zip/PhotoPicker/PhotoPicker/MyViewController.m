//
//  ViewController.m
//  PhotoPicker
//
//  Created by Esan on 2020/6/8.
//  Copyright © 2020 imac. All rights reserved.
//

#import "MyViewController.h"
#import "PPPhotoCollectionViewCell.h"
#import "PPPhotoPickerAssetsViewController.h"
#import <Masonry/Masonry.h>

@interface MyViewController ()<UICollectionViewDelegate,UICollectionViewDataSource>
@property (nonatomic,strong) UICollectionView *collectionView;
@property (nonatomic,strong) NSMutableArray *selectedArray;
@end
#define  IS_iPhoneX ([UIScreen instancesRespondToSelector:@selector(currentMode)] ? (CGSizeEqualToSize(CGSizeMake(1125, 2436), [[UIScreen mainScreen] currentMode].size)||CGSizeEqualToSize(CGSizeMake(1242, 2688), [[UIScreen mainScreen] currentMode].size)||CGSizeEqualToSize(CGSizeMake(828, 1792), [[UIScreen mainScreen] currentMode].size)) : NO)

#define  kNavHeadMargin        (IS_iPhoneX ? 88.f : 64.f)
#define  kTabbarSafeBottomMargin        (IS_iPhoneX ? 34.f : 0.f)

#define KScreenWidth [UIScreen mainScreen].bounds.size.width
#define KScreenHeight [UIScreen mainScreen].bounds.size.height
@implementation MyViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"一个很low的模拟";
    // Do any additional setup after loading the view.
    UIButton *selectBtn = [UIButton new];
    [selectBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    selectBtn.titleLabel.font = [UIFont systemFontOfSize:13];
    selectBtn.frame = CGRectMake(100,80,60,30);
    [selectBtn setTitle:@"选择照片" forState:UIControlStateNormal];
    [selectBtn setBackgroundColor:[UIColor orangeColor]];
    [selectBtn addTarget:self action:@selector(select) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:selectBtn];
    
    [self.view addSubview:self.collectionView];
    [self.collectionView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.bottom.mas_equalTo(0);
        make.top.mas_equalTo(selectBtn.mas_bottom).offset(20);
    }];
}
- (void)select {
    
    PPPhotoPickerAssetsViewController *vc = [PPPhotoPickerAssetsViewController new];
    vc.modalPresentationStyle = UIModalPresentationFullScreen;
    __weak typeof(self) weakSelf = self;
    vc.selelctDoneBlock = ^(NSArray<PPPhotoAssetModel *> * _Nonnull assetModelArray) {
        [weakSelf.selectedArray addObjectsFromArray:assetModelArray];
        [weakSelf.collectionView reloadData];
    };
    UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:vc];
    nav.modalPresentationStyle = UIModalPresentationFullScreen;
    [self.navigationController  presentViewController:nav animated:YES completion:nil];
}


- (UICollectionView *)collectionView{
    if (!_collectionView) {
        NSInteger cellW = (KScreenWidth - 2 * 5 + 0) / 4;
        UICollectionViewFlowLayout *layout = [[UICollectionViewFlowLayout alloc] init];
        layout.itemSize = CGSizeMake(cellW, cellW);
        layout.sectionInset = UIEdgeInsetsMake(0, 2, 0, 2);
        layout.minimumInteritemSpacing = 0;
        layout.minimumLineSpacing = 2;
        
        UICollectionView *collectionView = [[UICollectionView alloc] initWithFrame:CGRectZero collectionViewLayout:layout];
        [collectionView registerClass:[PPPhotoCollectionViewCell class] forCellWithReuseIdentifier:@"PPPhotoCollectionViewCell"];
        collectionView.backgroundColor = [UIColor whiteColor];
        collectionView.contentInset = UIEdgeInsetsMake(2, 0,2, 0);
        collectionView.delegate = self;
        collectionView.dataSource = self;
        _collectionView = collectionView;
    }
    return _collectionView;
}
- (NSMutableArray *)selectedArray{
    if (_selectedArray == nil) {
        _selectedArray = [NSMutableArray new];
    }
    return _selectedArray;
}
#pragma mark -<UICollectionViewDataSource>
- (NSInteger) numberOfSectionsInCollectionView:(UICollectionView *)collectionView{
    return 1;
}

- (NSInteger) collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    return self.selectedArray.count;
}

- (UICollectionViewCell *) collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    PPPhotoCollectionViewCell *cell = [PPPhotoCollectionViewCell cellWithCollectionView:collectionView cellForItemAtIndexPath:indexPath];
    cell.model = self.selectedArray[indexPath.item];
    
    return cell;
}
@end
