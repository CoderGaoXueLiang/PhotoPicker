//
//  PPPhotoBrowserViewController.m
//
//
//  Created by Esan on 2020/5/29.
//  Copyright © 2020 imac. All rights reserved.
//

#import "PPPhotoBrowserViewController.h"
#import <Masonry/Masonry.h>
#import "PPPhotoBrowserCollectionCell.h"
#import "PPPhotoAssetModel.h"

@interface PPPhotoBrowserViewController ()
<UICollectionViewDelegate,UICollectionViewDataSource>
@property (nonatomic,strong) UIView *nav;
@property (nonatomic,strong) UICollectionView *collectionView;

@end

#define  IS_iPhoneX ([UIScreen instancesRespondToSelector:@selector(currentMode)] ? (CGSizeEqualToSize(CGSizeMake(1125, 2436), [[UIScreen mainScreen] currentMode].size)||CGSizeEqualToSize(CGSizeMake(1242, 2688), [[UIScreen mainScreen] currentMode].size)||CGSizeEqualToSize(CGSizeMake(828, 1792), [[UIScreen mainScreen] currentMode].size)) : NO)

#define  kNavHeadMargin        (IS_iPhoneX ? 88.f : 64.f)

#define KScreenWidth [UIScreen mainScreen].bounds.size.width
#define KScreenHeight [UIScreen mainScreen].bounds.size.height

@implementation PPPhotoBrowserViewController
{
    CGPoint _draggingPoint;
    NSInteger _page;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self setNavBar];
}
- (void)setNavBar {
    [self.navigationController setNavigationBarHidden:YES animated:YES];
    UIView * navBgView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, KScreenWidth, kNavHeadMargin)];
    navBgView.backgroundColor = [UIColor blackColor];
    navBgView.hidden = NO;
    [self.view addSubview:navBgView];
    self.nav = navBgView;

    UIButton *backButton = [UIButton buttonWithType:UIButtonTypeCustom];
    backButton.adjustsImageWhenHighlighted = NO;
    [backButton setTitle:@"返回" forState:UIControlStateNormal];
    backButton.titleLabel.font = [UIFont systemFontOfSize:16];
    CGSize buttonTitleLabelSize = [@"返回" sizeWithAttributes:@{NSFontAttributeName:backButton.titleLabel.font}];
    backButton.frame = CGRectMake(0,0,buttonTitleLabelSize.width+15,
                                  buttonTitleLabelSize.height);
    backButton.imageEdgeInsets = UIEdgeInsetsMake(0, 0, 0, 10);
    [backButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [backButton addTarget:self action:@selector(popVC) forControlEvents:UIControlEventTouchUpInside];
    [navBgView addSubview:backButton];
    [backButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.mas_equalTo(-10);
        make.left.mas_equalTo(12);
        make.size.mas_equalTo(CGSizeMake(backButton.frame.size.width, backButton.frame.size.height));
    }];

    _page = self.index >= 0 ? self.index : 0;
    [self.view addSubview:self.collectionView];
    [self.collectionView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.mas_equalTo(self.view);
    }];
    if (@available(iOS 11.0, *)) {
        self.collectionView.contentInsetAdjustmentBehavior = UIScrollViewContentInsetAdjustmentNever;
    } else {
        // Fallback on earlier versions
    }
    [self.view bringSubviewToFront:self.nav];
    [self.collectionView reloadData];
    NSIndexPath *indexPath = [NSIndexPath indexPathForItem:self.index inSection:0];
    [self.collectionView scrollToItemAtIndexPath:indexPath atScrollPosition:UICollectionViewScrollPositionNone animated:NO];
}
- (void)popVC {
    [self.navigationController popViewControllerAnimated:YES];
}

#pragma mark -<UICollectionViewDataSource>
- (NSInteger) numberOfSectionsInCollectionView:(UICollectionView *)collectionView{
    return 1;
}

- (NSInteger) collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    return self.photoBrowserArray.count;
}

- (UICollectionViewCell *) collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    PPPhotoBrowserCollectionCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"PPPhotoBrowserCollectionCell" forIndexPath:indexPath];
    PPPhotoAssetModel *model = self.photoBrowserArray[indexPath.row];
    cell.model = model;
    return cell;
}


#pragma mark - <UICollectionViewDelegate>
- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
    
    [UIView animateWithDuration:0.3 animations:^{
        if (self.nav.alpha == 0.f) {
            self.nav.alpha = 1.f;
            collectionView.backgroundColor = [UIColor whiteColor];
        }else {
            self.nav.alpha = 0.f;
            collectionView.backgroundColor = [UIColor blackColor];
        }
    }];
}
- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView {
    _draggingPoint = scrollView.contentOffset;
}

- (void)scrollViewWillBeginDecelerating:(UIScrollView *)scrollView {
    [self collectionEndScroll:scrollView];
}

- (void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate {
    if (!decelerate) {
        [self collectionEndScroll:scrollView];
    }
}

- (void)collectionEndScroll:(UIScrollView *)scrollView {
    CGFloat width = _collectionView.frame.size.width;
    if(scrollView.contentOffset.x > _draggingPoint.x){//next
        if (scrollView.contentOffset.x - _draggingPoint.x > width * 0.15) {
            if (_page < self.photoBrowserArray.count - 1) {
            _page ++;
            }
        }
        [scrollView setContentOffset:CGPointMake(_page*(width + 20) , 0) animated:YES];
    }
    else {//last
        if (_draggingPoint.x - scrollView.contentOffset.x > width * 0.15) {
            if (_page > 0) {
                _page--;
            }
        }
        [scrollView setContentOffset:CGPointMake(_page*(width + 20) , 0) animated:YES];
    }
}
#pragma mark - set/get
- (void)setIndex:(NSInteger)index {
    if (index<0) {
        index = 0;
    }
    _index = index;
    _page = index;
}
-(NSMutableArray *)photoBrowserArray {
    if (!_photoBrowserArray) {
        _photoBrowserArray = [NSMutableArray new];
    }
    return _photoBrowserArray;
}
#pragma mark collectionView
- (UICollectionView *)collectionView{
    if (!_collectionView) {
        UICollectionViewFlowLayout *layout = [[UICollectionViewFlowLayout alloc] init];
        layout.itemSize = CGSizeMake(KScreenWidth, KScreenHeight);
        layout.sectionInset = UIEdgeInsetsMake(0, 0, 0, 0);
        layout.minimumInteritemSpacing = 0;
        layout.minimumLineSpacing = 20;
        layout.scrollDirection = UICollectionViewScrollDirectionHorizontal;
        
        UICollectionView *collectionView = [[UICollectionView alloc] initWithFrame:self.view.bounds collectionViewLayout:layout];
        [collectionView registerClass:[PPPhotoBrowserCollectionCell class] forCellWithReuseIdentifier:@"PPPhotoBrowserCollectionCell"];
        collectionView.backgroundColor = [UIColor whiteColor];
        collectionView.contentInset = UIEdgeInsetsMake(0, 0 , 0, 0);
        collectionView.showsHorizontalScrollIndicator = NO;
        collectionView.showsVerticalScrollIndicator = NO;
        collectionView.delegate = self;
        collectionView.dataSource = self;
        _collectionView = collectionView;
    }
    return _collectionView;
}

@end
