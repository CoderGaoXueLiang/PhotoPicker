//
//  PPPhotoPickerAssetsViewController.m
//
//
//  Created by Esan on 2020/5/29.
//  Copyright © 2020 imac All rights reserved.
//

#import "PPPhotoPickerAssetsViewController.h"
#import <Masonry/Masonry.h>
#import "PPPhotoBrowserViewController.h"
#import "PPPhotoPickerCollectionCell.h"
#import "PPPhotoAssetModel.h"
#import <Photos/Photos.h>

@interface PPPhotoPickerAssetsViewController ()
<UICollectionViewDelegate,UICollectionViewDataSource,PPPhotoPickerCollectionCelldelegate>

@property (nonatomic,strong) UIView *navBar;
@property (nonatomic,strong) UIView *bottomBar;
@property (nonatomic,strong) UICollectionView *collectionView;
@property (nonatomic,strong) UIButton *doneBtn;
@property (nonatomic,assign) NSInteger selectCount;
@property (nonatomic,strong) NSMutableArray *selectedArray;
@property (nonatomic,strong) NSMutableArray *allPhotoArray;
@property (nonatomic,strong) PHFetchResult<PHAsset *> *phAssets;
@end
#define  IS_iPhoneX ([UIScreen instancesRespondToSelector:@selector(currentMode)] ? (CGSizeEqualToSize(CGSizeMake(1125, 2436), [[UIScreen mainScreen] currentMode].size)||CGSizeEqualToSize(CGSizeMake(1242, 2688), [[UIScreen mainScreen] currentMode].size)||CGSizeEqualToSize(CGSizeMake(828, 1792), [[UIScreen mainScreen] currentMode].size)) : NO)

#define  kNavHeadMargin        (IS_iPhoneX ? 88.f : 64.f)
#define  kTabbarSafeBottomMargin        (IS_iPhoneX ? 34.f : 0.f)

#define KScreenWidth [UIScreen mainScreen].bounds.size.width
#define KScreenHeight [UIScreen mainScreen].bounds.size.height
@implementation PPPhotoPickerAssetsViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self configInitialData];
    [self setNavBar];
    [self setBottomBar];
    [self setCollectionView];
    [self searchAllImages];
}

- (void)setNavBar {
    [self.navigationController setNavigationBarHidden:YES animated:YES];
    UIView * navBgView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, KScreenWidth, kNavHeadMargin)];
    navBgView.backgroundColor = [UIColor blackColor];
    [self.view addSubview:navBgView];
    self.navBar = navBgView;
    
    UILabel *navTitle = [UILabel new];
    navTitle.text = @"我的照片";
    navTitle.font = [UIFont boldSystemFontOfSize:17];
    navTitle.textColor = [UIColor whiteColor];
    [navBgView addSubview:navTitle];
    [navTitle mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.mas_equalTo(navBgView);
        make.bottom.mas_equalTo(navBgView.mas_bottom).offset(-10);
    }];
    
    UIButton *backButton = [UIButton buttonWithType:UIButtonTypeCustom];
    backButton.adjustsImageWhenHighlighted = NO;
    [backButton setTitle:@"返回" forState:UIControlStateNormal];
    backButton.titleLabel.font = [UIFont systemFontOfSize:16];
    CGSize buttonTitleLabelSize = [@"返回" sizeWithAttributes:@{NSFontAttributeName:backButton.titleLabel.font}];
    backButton.frame = CGRectMake(0,0,buttonTitleLabelSize.width+15,buttonTitleLabelSize.height);
    backButton.imageEdgeInsets = UIEdgeInsetsMake(0, 0, 0, 10);
    [backButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [backButton addTarget:self action:@selector(dismissVC) forControlEvents:UIControlEventTouchUpInside];
    [navBgView addSubview:backButton];
    [backButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.mas_equalTo(navTitle);
        make.left.mas_equalTo(12);
        make.size.mas_equalTo(CGSizeMake(backButton.frame.size.width, backButton.frame.size.height));
    }];
    
    
}
- (void)setBottomBar {
    CGFloat toolH = 55.f + kTabbarSafeBottomMargin;
    UIView * bottomToolView = [[UIView alloc] initWithFrame:CGRectMake(0, KScreenHeight-toolH, KScreenWidth, toolH)];
    bottomToolView.backgroundColor = [UIColor blackColor];
    [self.view addSubview:bottomToolView];
    self.bottomBar = bottomToolView;
    
    UIButton *doneBtn = [UIButton new];
    [doneBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [doneBtn setTitleColor:[UIColor lightGrayColor] forState:UIControlStateDisabled];
    doneBtn.enabled = NO;
    doneBtn.titleLabel.font = [UIFont systemFontOfSize:16];
    CGFloat doneBtnW = 50.f;
    CGFloat doneBtnH = 30.f;
    doneBtn.frame = CGRectMake(KScreenWidth-doneBtnW-15, (toolH-doneBtnH)*0.5, doneBtnW, doneBtnH);
    [doneBtn setTitle:@"完成" forState:UIControlStateNormal];
    [doneBtn setBackgroundColor:[UIColor grayColor]];
    doneBtn.layer.cornerRadius = 3;
    doneBtn.layer.masksToBounds = YES;
    [doneBtn addTarget:self action:@selector(done) forControlEvents:UIControlEventTouchUpInside];
    self.doneBtn = doneBtn;
    [self.bottomBar addSubview:doneBtn];
    
}
- (void) setCollectionView{
    [self.view addSubview:self.collectionView];
    [self.collectionView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.mas_equalTo(self.view);
        make.top.mas_equalTo(self.navBar.mas_bottom);
        make.bottom.mas_equalTo(self.bottomBar.mas_top);
    }];
}
- (void)configInitialData {
    self.selectCount = 0;
    self.maxSelectCount = 9;
}
- (void)add{
    self.selectCount += 1;
}
- (void)plus{
    self.selectCount--;
}
#pragma mark collectionView
- (UICollectionView *)collectionView{
    if (!_collectionView) {
        NSInteger cellW = (KScreenWidth - 2 * 5 + 0) / 4;
        UICollectionViewFlowLayout *layout = [[UICollectionViewFlowLayout alloc] init];
        layout.itemSize = CGSizeMake(cellW, cellW);
        layout.sectionInset = UIEdgeInsetsMake(0, 2, 0, 2);
        layout.minimumInteritemSpacing = 0;
        layout.minimumLineSpacing = 2;
        
        UICollectionView *collectionView = [[UICollectionView alloc] initWithFrame:CGRectZero collectionViewLayout:layout];
        [collectionView registerClass:[PPPhotoPickerCollectionCell class] forCellWithReuseIdentifier:@"PPPhotoPickerCollectionCell"];
        collectionView.backgroundColor = [UIColor whiteColor];
        collectionView.contentInset = UIEdgeInsetsMake(2, 0,2, 0);
        collectionView.delegate = self;
        collectionView.dataSource = self;
        _collectionView = collectionView;
    }
    return _collectionView;
}
- (NSMutableArray *)selectedArray{
    if (_selectedArray == nil) {
        _selectedArray = [NSMutableArray new];
    }
    return _selectedArray;
}
- (NSMutableArray *)allPhotoArray{
    if (_allPhotoArray == nil) {
        _allPhotoArray = [NSMutableArray new];
    }
    return _allPhotoArray;
}
- (void)setSelectCount:(NSInteger)selectCount {
    _selectCount = selectCount;
    self.doneBtn.enabled = selectCount>0?YES:NO;
    CGRect rect = self.doneBtn.frame;
    if (selectCount > 0) {
        rect.size.width = 70;
        rect.origin.x = KScreenWidth-70-15;
        [self.doneBtn setBackgroundColor:[UIColor blueColor]];
        [self.doneBtn setTitle:[NSString stringWithFormat:@"完成(%ld)",selectCount] forState:UIControlStateNormal];
    }else {
        rect.size.width = 50;
        rect.origin.x = KScreenWidth-50-15;
        [self.doneBtn setBackgroundColor:[UIColor grayColor]];
        [self.doneBtn setTitle:@"完成" forState:UIControlStateNormal];
    }
    self.doneBtn.frame = rect;
}
- (void)setMaxSelectCount:(NSInteger)maxSelectCount {
    _maxSelectCount = maxSelectCount;
    if (maxSelectCount <= 0) {
        maxSelectCount = 9;
    }
}
- (void)done {
    self.selelctDoneBlock(self.selectedArray);
    [self dismissViewControllerAnimated:YES completion:nil];
}
- (void)dismissVC {
    [self dismissViewControllerAnimated:YES completion:nil];
}
#pragma mark -<UICollectionViewDataSource>
- (NSInteger) numberOfSectionsInCollectionView:(UICollectionView *)collectionView{
    return 1;
}

- (NSInteger) collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    return self.allPhotoArray.count;
}

- (UICollectionViewCell *) collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    __weak typeof(self) weakSelf = self;
   __weak PPPhotoPickerCollectionCell *cell = [PPPhotoPickerCollectionCell cellWithCollectionView:collectionView cellForItemAtIndexPath:indexPath];
    cell.delegate = self;
    cell.model = self.allPhotoArray[indexPath.item];
    cell.maxSelectCount = self.maxSelectCount;
    cell.selectBlock = ^(BOOL isSelected ,PPPhotoAssetModel * _Nonnull model) {
        if (weakSelf.selectCount == weakSelf.maxSelectCount && !isSelected) {
            NSString *format = [NSString stringWithFormat:@"您最多只能选择%zd张图片",weakSelf.maxSelectCount];
            UIAlertController *alert = [UIAlertController alertControllerWithTitle:nil message:format preferredStyle:UIAlertControllerStyleAlert];
            UIAlertAction *ok = [UIAlertAction actionWithTitle:@"好的" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {}];
            [alert addAction:ok];
            [weakSelf presentViewController:alert animated:YES completion:nil];
            return;
        }
        cell.selectBtn.selected =! cell.selectBtn.selected;
        cell.maskView.hidden =! cell.selectBtn.selected;
        if (cell.selectBtn.selected) {
            [weakSelf.selectedArray addObject:model];
        }else {
            [weakSelf.selectedArray removeObject:model];
        }
        weakSelf.selectCount = weakSelf.selectedArray.count;
    };
    return cell;
}

#pragma mark - <UICollectionViewDelegate>
- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
    PPPhotoBrowserViewController *vc = [PPPhotoBrowserViewController new];
    vc.photoBrowserArray = self.allPhotoArray;
    vc.index = indexPath.row;
    [self.navigationController pushViewController:vc animated:YES];
}

#pragma  mark - PPPhotoPickerCollectionCelldelegate
- (void)didSelectedPhotoWithIndex:(NSInteger)index Status:(BOOL)isSelected SelectedModel:(nonnull PPPhotoAssetModel *)seletedModel{
    if (isSelected) {
        [self.selectedArray addObject:seletedModel];
    }else {
        [self.selectedArray removeObject:seletedModel];
    }
    self.selectCount = self.selectedArray.count;
}
#pragma mark - 获取相册资源
- (void)searchAllImages {
    [PHPhotoLibrary requestAuthorization:^(PHAuthorizationStatus status) {
        if (status != PHAuthorizationStatusAuthorized){
            return;
        }
        dispatch_async(dispatch_get_main_queue(), ^{
        });
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
            PHFetchResult<PHAssetCollection *> *collectionResult0 = [PHAssetCollection fetchAssetCollectionsWithType:PHAssetCollectionTypeAlbum subtype:PHAssetCollectionSubtypeAlbumRegular options:nil];
            for (PHAssetCollection *collection in collectionResult0) {
                [self searchAllImagesInCollection:collection];
            }
            PHAssetCollection *cameraRoll = [PHAssetCollection fetchAssetCollectionsWithType:PHAssetCollectionTypeSmartAlbum subtype:PHAssetCollectionSubtypeSmartAlbumUserLibrary options:nil].lastObject;
            [self searchAllImagesInCollection:cameraRoll];
        });
    }];
}

- (void)searchAllImagesInCollection:(PHAssetCollection *)collection {
    PHImageRequestOptions *imageOptions = [[PHImageRequestOptions alloc] init];
    imageOptions.synchronous = YES;
    
    PHFetchResult<PHAsset *> *assetResult = [PHAsset fetchAssetsInAssetCollection:collection options:nil];
    __weak typeof(self) weakSelf = self;
    for (PHAsset *asset in assetResult) {
        if (asset.mediaType != PHAssetMediaTypeImage) continue;
        
        CGSize photoSize = CGSizeMake(asset.pixelWidth, asset.pixelHeight);
        PPPhotoAssetModel *model = [PPPhotoAssetModel new];
        
        [[PHImageManager defaultManager] requestImageForAsset:asset targetSize:photoSize contentMode:PHImageContentModeDefault options:imageOptions resultHandler:^(UIImage * _Nullable result, NSDictionary * _Nullable info) {
            model.thumbImage = result;
            model.imageSize = CGSizeMake(asset.pixelWidth, asset.pixelHeight);
            [weakSelf.allPhotoArray addObject:model];
        }];
    }
    dispatch_async(dispatch_get_main_queue(), ^{
        [weakSelf.collectionView reloadData];
    });
}

@end
