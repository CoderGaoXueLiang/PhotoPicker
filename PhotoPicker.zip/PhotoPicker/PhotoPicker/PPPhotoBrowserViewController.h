//
//  PPPhotoBrowserViewController.h
//
//
//  Created by Esan on 2020/5/29.
//  Copyright © 2020 imac. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface PPPhotoBrowserViewController : UIViewController
@property (nonatomic,strong) NSMutableArray *photoBrowserArray;
/**
 *  上一页查看的当前photo的下标
 */
@property (assign,nonatomic) NSInteger index;
@end

NS_ASSUME_NONNULL_END
