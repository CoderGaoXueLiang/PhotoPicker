//
//  PPPhotoPickerAssetsViewController.h
//
//
//  Created by Esan on 2020/5/29.
//  Copyright © 2020 imac All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PPPhotoAssetModel.h"

NS_ASSUME_NONNULL_BEGIN

typedef void(^CallBackSelelctDoneBlock)(NSArray<PPPhotoAssetModel *> *assetModelArray);

@interface PPPhotoPickerAssetsViewController : UIViewController
@property (nonatomic,assign) NSInteger maxSelectCount;
@property (nonatomic, copy) CallBackSelelctDoneBlock selelctDoneBlock;
@end

NS_ASSUME_NONNULL_END
