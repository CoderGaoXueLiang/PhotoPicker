//
//  PPPhotoPickerCollectionCell.h
//
//
//  Created by Esan on 2020/5/29.
//  Copyright © 2020 imac. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PPPhotoAssetModel.h"

NS_ASSUME_NONNULL_BEGIN

typedef void (^CallBackSelectBlock)(BOOL isSelected ,PPPhotoAssetModel *model);

@protocol PPPhotoPickerCollectionCelldelegate <NSObject>

- (void)didSelectedPhotoWithIndex:(NSInteger)index Status:(BOOL)isSelected CollectionView:(UICollectionView *)collectionView;
- (void)didSelectedPhotoWithIndex:(NSInteger)index Status:(BOOL)isSelected SelectedModel:(PPPhotoAssetModel *)seletedModel;
@end

@interface PPPhotoPickerCollectionCell : UICollectionViewCell
@property (nonatomic,strong) UIImageView *imgView;
@property (nonatomic,strong) UIButton *selectBtn;
@property (nonatomic,strong) UIView *maskView;

@property (nonatomic,strong) PPPhotoAssetModel *model;
@property (nonatomic,assign) NSInteger maxSelectCount;
@property (nonatomic,copy) CallBackSelectBlock selectBlock;

@property (nonatomic,assign) id <PPPhotoPickerCollectionCelldelegate>delegate;


+ (instancetype) cellWithCollectionView : (UICollectionView *) collectionView cellForItemAtIndexPath:(NSIndexPath *) indexPath;
@end

NS_ASSUME_NONNULL_END
