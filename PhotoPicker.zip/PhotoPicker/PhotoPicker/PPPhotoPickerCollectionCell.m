//
//  PPPhotoPickerCollectionCell.m
//
//
//  Created by Esan on 2020/5/29.
//  Copyright © 2020 imac. All rights reserved.
//

#import "PPPhotoPickerCollectionCell.h"
#import <Masonry/Masonry.h>

@implementation PPPhotoPickerCollectionCell
+ (instancetype) cellWithCollectionView : (UICollectionView *) collectionView cellForItemAtIndexPath:(NSIndexPath *) indexPath {
    PPPhotoPickerCollectionCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"PPPhotoPickerCollectionCell" forIndexPath:indexPath];
    
    [cell addViewsWithIndex:indexPath.item];
    return cell;
}
- (void)addViewsWithIndex:(NSInteger)index{
    UIImageView *img = [UIImageView new];
    img.contentMode = UIViewContentModeScaleAspectFill;
    img.layer.masksToBounds = YES;
    [self.contentView addSubview:img];
    [img mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.mas_equalTo(self.contentView);
    }];
    img.userInteractionEnabled = YES;
    self.imgView = img;
    
    UIView *maskView = [[UIView alloc] init];
    maskView.userInteractionEnabled = YES;
    maskView.frame = self.bounds;
    maskView.backgroundColor = [UIColor blackColor];
    maskView.alpha = 0.45;
    [self.contentView addSubview:maskView];
    [img mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.mas_equalTo(self.contentView);
    }];
    maskView.hidden = YES;
    self.maskView = maskView;
    
    UIButton *selectBtn = [UIButton new];
    selectBtn.tag = index;
    [selectBtn setBackgroundImage:[UIImage imageNamed:@"unselect"] forState:UIControlStateNormal];
    [selectBtn setBackgroundImage:[UIImage imageNamed:@"selected"] forState:UIControlStateSelected];
    [self.contentView addSubview:selectBtn];
    [selectBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(5);
        make.right.mas_equalTo(-5);
        make.size.mas_equalTo(CGSizeMake(25, 25));
    }];
    
    self.selectBtn = selectBtn;
    [selectBtn addTarget:self action:@selector(didSelect:) forControlEvents:UIControlEventTouchUpInside];
}
- (void)didSelect:(UIButton *)selectBtn {
    CAKeyframeAnimation *scaoleAnimation = [CAKeyframeAnimation animationWithKeyPath:@"transform.scale"];
    scaoleAnimation.duration = 0.25;
    scaoleAnimation.values = @[[NSNumber numberWithFloat:1.0],[NSNumber numberWithFloat:1.1],[NSNumber numberWithFloat:1.0]];
    scaoleAnimation.fillMode = kCAFillModeForwards;
    [self.selectBtn.layer addAnimation:scaoleAnimation forKey:@"transform.rotate"];
    self.selectBlock(selectBtn.selected,self.model);
}
- (void)setModel:(PPPhotoAssetModel *)model {
    _model = model;
    self.imgView.image = model.thumbImage;
}
@end
