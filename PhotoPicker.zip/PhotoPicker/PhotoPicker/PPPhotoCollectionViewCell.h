//
//  PPPhotoCollectionViewCell.h
//  PhotoPicker
//
//  Created by Esan on 2020/5/29.
//  Copyright © 2020 imac. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PPPhotoAssetModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface PPPhotoCollectionViewCell : UICollectionViewCell
@property (nonatomic,strong) UIImageView *imgView;
@property (nonatomic,strong) PPPhotoAssetModel *model;

+ (instancetype) cellWithCollectionView : (UICollectionView *) collectionView cellForItemAtIndexPath:(NSIndexPath *) indexPath;
@end

NS_ASSUME_NONNULL_END
