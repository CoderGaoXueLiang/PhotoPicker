//
//  PPPhotoBrowserCollectionCell.m
//
//
//  Created by Esan on 2020/6/3.
//  Copyright © 2020 imac. All rights reserved.
//

#import "PPPhotoBrowserCollectionCell.h"
#import <Masonry/Masonry.h>

@interface PPPhotoBrowserCollectionCell ()

@end

@implementation PPPhotoBrowserCollectionCell
{
    UIImageView *_imageView;
}
- (id)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if(self) {
        [self addViews];
    }
    return self;
}
+ (instancetype) cellWithCollectionView : (UICollectionView *) collectionView cellForItemAtIndexPath:(NSIndexPath *) indexPath {
    PPPhotoBrowserCollectionCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"PPPhotoBrowserCollectionCell" forIndexPath:indexPath];
    
    [cell addViews];
    return cell;
}
- (void)addViews {
    UIImageView *img = [UIImageView new];
    img.contentMode = UIViewContentModeScaleAspectFit;
    [self.contentView addSubview:img];
    [img mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.mas_equalTo(self.contentView);
    }];
    _imageView = img;
}
- (void)setModel:(PPPhotoAssetModel *)model {
    _model = model;
    _imageView.image = model.thumbImage;
}
@end
