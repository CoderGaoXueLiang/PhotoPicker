//
//  PPPhotoCollectionViewCell.m
//  PhotoPicker
//
//  Created by Esan on 2020/5/29.
//  Copyright © 2020 imac. All rights reserved.
//

#import "PPPhotoCollectionViewCell.h"
#import <Masonry/Masonry.h>

@implementation PPPhotoCollectionViewCell
+ (instancetype) cellWithCollectionView : (UICollectionView *) collectionView cellForItemAtIndexPath:(NSIndexPath *) indexPath {
    PPPhotoCollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"PPPhotoCollectionViewCell" forIndexPath:indexPath];
    [cell addViewsWithIndex:indexPath.item];
    return cell;
}
- (void)addViewsWithIndex:(NSInteger)index{
    UIImageView *img = [UIImageView new];
    img.contentMode = UIViewContentModeScaleAspectFill;
    img.layer.masksToBounds = YES;
    [self.contentView addSubview:img];
    [img mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.mas_equalTo(self.contentView);
    }];
    img.userInteractionEnabled = YES;
    self.imgView = img;
    
}
- (void)setModel:(PPPhotoAssetModel *)model {
    _model = model;
    self.imgView.image = model.thumbImage;
}
@end
