//
//  PPPhotoAssetModel.h
//
//
//  Created by Esan on 2020/5/29.
//  Copyright © 2020 imac. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <Photos/Photos.h>

NS_ASSUME_NONNULL_BEGIN

@interface PPPhotoAssetModel : NSObject
/**
 *   PHAsset对象
 */
@property (nonatomic,strong) PHAsset *asset;
/**
 *  缩略图
 */
@property (nonatomic, strong) UIImage *aspectRatioImage;
/**
 *  缩略图
 */
@property (nonatomic, strong) UIImage *thumbImage;
/**
 *  原图
 */
@property (nonatomic, strong) UIImage *originImage;
/**
 *  获取图片的URL
 */
@property (strong,nonatomic) NSURL *assetURL;
/**
 *  获取图片的尺寸
 */
@property (assign,nonatomic) CGSize imageSize;


@end

NS_ASSUME_NONNULL_END
