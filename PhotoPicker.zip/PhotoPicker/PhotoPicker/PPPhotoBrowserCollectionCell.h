//
//  PPPhotoBrowserCollectionCell.h
//
//
//  Created by Esan on 2020/6/3.
//  Copyright © 2020 imac. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PPPhotoAssetModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface PPPhotoBrowserCollectionCell : UICollectionViewCell
@property (nonatomic,strong) PPPhotoAssetModel *model;

+ (instancetype) cellWithCollectionView : (UICollectionView *) collectionView cellForItemAtIndexPath:(NSIndexPath *) indexPath;
@end

NS_ASSUME_NONNULL_END
